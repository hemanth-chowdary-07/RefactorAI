package com.refactorai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefactorAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
