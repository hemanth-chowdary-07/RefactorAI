package com.refactorai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefactorAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefactorAiApplication.class, args);
	}

}
